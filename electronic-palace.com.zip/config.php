<?php
$currency = '$'; //Currency sumbol or code

	$username = "electronicpalace";
	$password = "abcde12345";
	$hostname = "localhost";  
	$database = "electronicpalace";
	$mysqli= mysqli_connect($hostname, $username, $password,$database) 
	or die("Unable to connect to MySQL");
	 


	?>
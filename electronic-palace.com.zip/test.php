<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
<meta http-equiv="Content-Type" content="text/html;
charset=utf-8">

<title> Index </title>
<style type="text/css">
html{
background-color:#ffffff;
}
img {
	padding:15px; 
	}
	
.borderit img{
	border: 1px solid #e5e6ea;
	height:200;
	width:180;
	}
	.borderit:hover img{
border: 2px solid Black;
}
.borderit:hover{
color: blue; 
}

#form-wrap{
width:1200px; 
border: 0px solid #ccc;
background-color:#ffffff;
margin: 10px auto;
padding: -10px 0px; <!-- height /width-->
}

form{
width: 1200px;
height:70px;

}
#form-wrapone{
width:1200px; 
border: 0px solid #ccc;
background-color:#ffffff;
margin: 10px auto;
padding: -10px 0px;
height:430px; <!-- height /width-->
}

#form-wraptwo{
width:1200px; 
border: 0px solid #ccc;
background-color:#ffffff;
margin: 10px auto;
padding: -200px 0px;
height:490px; <!-- height /width-->

}


#form-wrapthree{
width:1200px; 
border: 0px solid #ccc;
background-color:#ffffff;
margin: 10px auto;
padding: -100px 0px;
height:130px; <!-- height /width-->
}

fieldset{
border:none;
background-color :#f6f6f6f6;
padding : 0 0 20px 0;
}

.labelone{
margin-top:10px;

}

.btn{
width:125px;
background-color: #d6cfcf;
  
  border: 1px solid #2b0606;
  
  margin:20px 0 0 20px;
}

form h4{
margin:40px 0 0 20px;
font:24px sans-serif;
color: #4c4747;
font-weight:bold;

}

h2 {
background-color:#cbddef;
text-align:center;

}
h5 {
background-color:#f9f2f2;
text-align:center;
 height: 30px;
 margin: 0px;
 text-align:right;
 font-size:16px;
 text-decoration: none;

}
	#tfnewsearch{
		float:right;
		}
		
	.tftextinput{
		margin: 50px 100px;
		 display: inline-block;
		 position: relative;
		 left:30px;
		top:-85px;
		padding: 5px 40px;
		font-family: Arial, Helvetica, sans-serif;
		font-size:14px;
		border:1px solid #0076a3; border-right:0px;
		border-top-left-radius: 15px 15px;
		border-bottom-left-radius: 15px 15px;
	}
	.tfbutton {
		margin: 50px 100px;
		display: inline-block;
		position: relative;
		left:-190px;
		top:-85px;
		padding: 5px 45px;
		font-family: Arial, Helvetica, sans-serif;
		font-size:14px;
		cursor: pointer;
		text-align: center;
		text-decoration: none;
		color: #ffffff;
		border: solid 1px #0076a3; border-right:0px;
		background: #0095cd;
		background: -webkit-gradient(linear, left top, left bottom, from(#00adee), to(#0078a5));
		background: -moz-linear-gradient(top,  #00adee,  #0078a5);
		border-top-right-radius: 15px 15px;
		border-bottom-right-radius: 15px 15px;
	}
	.tfbutton:hover {
		text-decoration: none;
		background: #007ead;
		background: -webkit-gradient(linear, left top, left bottom, from(#0095cc), to(#00678e));
		background: -moz-linear-gradient(top,  #0095cc,  #00678e);
	}
	/* Fixes submit button height problem in Firefox */
	.tfbutton::-moz-focus-inner {
	  border: 0;
	}
	.tfclear{
		clear:both;
	}



.tffbutton {
		margin: 50px 100px;
		display: inline-block;
		position: relative;
		left:870px;
		top:-55px;
		background: #0095cd;
		padding: 5px 45px;
		color:#f9f7f7;

}
.tffbutton:hover {
		text-decoration: none;
		background: #007ead;
		background: -webkit-gradient(linear, left top, left bottom, from(#0095cc), to(#00678e));
		background: -moz-linear-gradient(top,  #0095cc,  #00678e);
	}
	
	IMG.displayed {
    display: block;
    margin-left: auto;
    margin-right: auto }
		
		.footer {
  position:relative;
  bottom: 0;
  width:1170px;
  padding: 1rem;
  background-color: #211f1f;
  text-align: Left;  
}
#nav {  
	width: 97%; 
	background-color: #333; 
	font-family:"Century Gothic", "HelveticaNeueLT Pro 45 Lt", sans-serif; 
	float: left; 
	
	
}
#nav li { 
	list-style: none; 
	float: left; 
	width: 120px; 
	height: 30px; 
	line-height: 30px; 
	text-align: center;
} 
#nav li a { 
	color: white; 
	text-decoration: none; 
	display: block; 
} 
#nav li a:hover { 
	background-color: #bfb9b9; 
} 
#home .home a, #home .home a:hover,
#tutorials .tutorials a, #tutorials .tutorials a:hover,
#about .about a, #about .about a:hover,
#contact .contact a, #contact .contact a:hover,
#news .news a, #news .news a:hover {
 	background-color: #FFF; 
	color: #000;
	cursor: default;  
} 		
#nav li ul { 
	position: absolute;  
	display: none; 
} 
#nav li:hover ul { 
	display: block; 
} 
#nav li ul li { 
	float: none; 
	display: inline; 
}
#nav li ul li a { 
	width: 118px; 
	position: relative; 
	border-left: 1px solid black; 
	border-right: 1px solid black; 
	border-bottom: 1px solid black; 
	background: #333; 
	color: #fff; 
}
#nav li ul li a:hover { 
	background: #bfb9b9; 
	color: #000; 
}
</style>
</head>
<body>
<div id="form-wrap">
<form>
<h5 align="center"> 
&nbsp &nbsp &nbsp;<a href="sellproducts.php" style="text-decoration: none">Sell On Electronic Palace</a> |
&nbsp &nbsp &nbsp;<a href="deals_of_the_day.php" style="text-decoration: none">Deals of the Day</a> |
&nbsp &nbsp &nbsp;<a href="Register.php" style="text-decoration: none">Register</a> 
&nbsp &nbsp;|  &nbsp &nbsp; <a href="sign.php" style="text-decoration: none">Sign In</a> </h5>	

<a href="index.php"><IMG src="image/logo.jpg" /></a> 

<form id="tfnewsearch" action="search_P.php" method="POST">
<input type="text" class="tftextinput" name="Search" size="40" maxlength="120">
<input type="submit" name="search" class="tfbutton">
</form>

<form method="post" action="view_cart.php">
<input type="submit" value="View Cart" class="tffbutton">
</form>
</div>
</form>

<div id="form-wrapone">
<form>
<body id="about">
  <div id="header">
    <ul id="nav">
      <li class="home"><a href="#">Phones</a></li>
      <li class="tutorials"><a href="#">Laptop</a>
      </li>
      <li class="home"><a href="#">Camera</a></li>
      <li class="news"><a href="#">Accessories</a>
        <ul>
          <li><a href="#">Cases</a></li>
          <li><a href="#">Hard Drives</a></li>
        </ul>
      </li>
      <li class="contact"><a href="#">Ipads</a></li>
	  <li class="contact"><a href="#">Tablets</a></li>
	  <li class="contact"><a href="#">Television</a></li>
	  	  <li class="contact"><a href="#">Desktops</a></li>

		  	  <li class="contact"><a href="#">Softwares</a></li>

	  
    </ul><!-- nav --> 
  </div><!-- header -->  
  <IMG  class="displayed" src="image/output.gif"  alt="..."/> 

</form>  
</div>

<div id="form-wraptwo">
<form>
<h2> What's On!! </h2>
<?php
include ('Database.php');
?>

<?php
	$result = mysqli_query($dbhandle,"SELECT * FROM homepageimages");
	$current_url = base64_encode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	echo '<table border="0" style="table-layout: fixed; width: 1200px">';
	$i=0;
			while($rows = mysqli_fetch_array($result))
			{					
			
					$source=$name1=$price=""; 
					$lengths=count($rows);						
					$counter=0;
							if($i%5==0)
							{
								echo "<tr>";
								$counter=1;
							}
							$source=$source=$rows{'imgsource'};
							$name1=$name1=$rows{'modelno'};
							$price=$price=$rows{'price'};
							$id =$rows{'h_id'};							
					?>
			
		
		<?php
	echo	'<td> <div class="borderit">';
		echo '<form method="post" action="cart_update.php" style="height: 160px">';
  echo '<img src="/'.$source.'">';
  echo '</div>';
  echo '<br>';
   echo '<br>';
    echo '<br>';
  echo '<h3>'.$name1.'</h3>';
  echo '<h3>'.$price.'</h3>';
  echo '<button class="add_to_cart">Add To Cart</button>';
  echo '<input type="hidden" name="product_qty" value="1" size="3" />';
  echo '<input type="hidden" name="product_code" value="'.$id.'" />';
  echo '<input type="hidden" name="type" value="add" />';
  echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
  echo '<input type="hidden" name="product_price" value="'.$price.'" />';
  echo '<input type="hidden" name="pro4duct_callfeatures" value="'.$source.'" />';
  echo '<input type="hidden" name="src" value="'.$source.'" />';
  echo '</form>';?>
		
		<form method="GET" action="view_homepageimages.php">
		
		<button type="submit" name="id" value="<?php echo "$id";?>" >View </Button> </form></td> 
		<?php
			if($counter<4)
						{
							$counter++;
						}
						else
						{
						echo "";
						}    
						$i++;
						}
					
						?> 
				  </table>
</form>
</div>

<div id="form-wraptwo">
<form>
<h2> What's On!! </h2>
<?php
include ('Database.php');
?>

<?php
	$result = mysqli_query($dbhandle,"SELECT * FROM homepageimages");
	$current_url = base64_encode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	echo '<table border="0" style="table-layout: fixed; width: 1200px">';
	$i=0;
			while($rows = mysqli_fetch_array($result))
			{					
			
					$source=$name1=$price=""; 
					$lengths=count($rows);						
					$counter=0;
							if($i%5==0)
							{
								echo "<tr>";
								$counter=1;
							}
							$source=$source=$rows{'imgsource'};
							$name1=$name1=$rows{'modelno'};
							$price=$price=$rows{'price'};
							$id =$rows{'h_id'};							
					?>
			
		
		<?php
	echo	'<td> <div class="borderit">';
		echo '<form method="post" action="cart_update.php" style="height: 160px">';
  echo '<img src="/'.$source.'">';
  echo '</div>';
  echo '<br>';
   echo '<br>';
    echo '<br>';
  echo '<h3>'.$name1.'</h3>';
  echo '<h3>'.$price.'</h3>';
  echo '<button class="add_to_cart">Add To Cart</button>';
  echo '<input type="hidden" name="product_qty" value="1" size="3" />';
  echo '<input type="hidden" name="product_code" value="'.$id.'" />';
  echo '<input type="hidden" name="type" value="add" />';
  echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
  echo '<input type="hidden" name="product_price" value="'.$price.'" />';
  echo '<input type="hidden" name="pro4duct_callfeatures" value="'.$source.'" />';
  echo '<input type="hidden" name="src" value="'.$source.'" />';
  echo '</form>';?>
		
		<form method="GET" action="view_homepageimages.php">
		
		<button type="submit" name="id" value="<?php echo "$id";?>" >View </Button> </form></td> 
		<?php
			if($counter<4)
						{
							$counter++;
						}
						else
						{
						echo "";
						}    
						$i++;
						}
					
						?> 
				  </table>
</form>
</div>

<div id="form-wraptwo">
<form>
<h2> What's On!! </h2>
<?php
include ('Database.php');
?>

<?php
	$result = mysqli_query($dbhandle,"SELECT * FROM homepageimages");
	$current_url = base64_encode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	echo '<table border="0" style="table-layout: fixed; width: 1200px">';
	$i=0;
			while($rows = mysqli_fetch_array($result))
			{					
			
					$source=$name1=$price=""; 
					$lengths=count($rows);						
					$counter=0;
							if($i%5==0)
							{
								echo "<tr>";
								$counter=1;
							}
							$source=$source=$rows{'imgsource'};
							$name1=$name1=$rows{'modelno'};
							$price=$price=$rows{'price'};
							$id =$rows{'h_id'};							
					?>
			
		
		<?php
	echo	'<td> <div class="borderit">';
		echo '<form method="post" action="cart_update.php" style="height: 160px">';
  echo '<img src="/'.$source.'">';
  echo '</div>';
  echo '<br>';
   echo '<br>';
    echo '<br>';
  echo '<h3>'.$name1.'</h3>';
  echo '<h3>'.$price.'</h3>';
  echo '<button class="add_to_cart">Add To Cart</button>';
  echo '<input type="hidden" name="product_qty" value="1" size="3" />';
  echo '<input type="hidden" name="product_code" value="'.$id.'" />';
  echo '<input type="hidden" name="type" value="add" />';
  echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
  echo '<input type="hidden" name="product_price" value="'.$price.'" />';
  echo '<input type="hidden" name="pro4duct_callfeatures" value="'.$source.'" />';
  echo '<input type="hidden" name="src" value="'.$source.'" />';
  echo '</form>';?>
		
		<form method="GET" action="view_homepageimages.php">
		
		<button type="submit" name="id" value="<?php echo "$id";?>" >View </Button> </form></td> 
		<?php
			if($counter<4)
						{
							$counter++;
						}
						else
						{
						echo "";
						}    
						$i++;
						}
					
						?> 
				  </table>
</form>
</div>
<div id="form-wrapthree">
<form>
<div class="footer">
&nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp   &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp; <a href="aboutus.php" style="text-decoration: none"> <font size="2" color="white">About Us </font></a></li> &nbsp &nbsp &nbsp &nbsp <font size="2" color="white">|</font>
&nbsp &nbsp &nbsp; <a href="" style="text-decoration: none"><font size="2" color="white">Delivery Information </font></a> &nbsp &nbsp &nbsp &nbsp <font size="2" color="white">|</font>
&nbsp &nbsp &nbsp; <a href="FAQ's.php" style="text-decoration: none"><font size="2" color="white">FAQ's </font></a> &nbsp &nbsp &nbsp &nbsp <font size="2" color="white">|</font>

&nbsp &nbsp &nbsp; <a href="contactus.php" style="text-decoration: none"><font size="2" color="white">Contact Us </font></a> &nbsp &nbsp &nbsp &nbsp <font size="2" color="white">|</font>
&nbsp &nbsp &nbsp; <a href="returnpolicy.php" style="text-decoration: none"> <font size="2" color="white">Returns </font></a> &nbsp &nbsp &nbsp &nbsp <font size="2" color="white">|</font>
&nbsp &nbsp &nbsp; <a href="" style="text-decoration: none"> <font size="2" color="white">Site Map</font></a>&nbsp &nbsp &nbsp &nbsp <font size="2" color="white">|</font>
&nbsp &nbsp &nbsp; <a href="feedback.php" style="text-decoration: none"> <font size="2" color="white">Feed Back</font></a>
				 
				 </font>
<hr>
<p align="center"> <font size="2" color="white"> Copyright 2014 Electronic Palace. All rights reserved.</font></p> 
</div>
</form>
</div>
</body>

</html>

<html>
<head>

<meta http-equiv="Content-Type" content="text/html;
charset=utf-8">

<title> About Us </title>
<style type="text/css">

html{

background-color:#ffffff;

}

#form-wrap{

width:600px;
border: 3px solid #ccc;
background-color:#ffffff;
margin: 50px auto;
padding: 30 px 0;

}

form{
width: 700px;
height:auto;

}
p{
margin:10px 0 0 20px;
font:14px sans-serif;
color: black;
width: 560px;
text-align:left;
}


fieldset{
border:none;
background-color :#f6f6f6f6;
padding : 0 0 20px 0;
}

.labelone{
margin-top:10px;

}

.btn{
width:125px;
background-color: #d6cfcf;
  
  border: 1px solid #2b0606;
  
  margin:20px 0 0 20px;
}

form h4{

margin:40px 0 0 20px;
font:24px sans-serif;
color: #4c4747;
font-weight:bold;

}
.mainsection {
text-align:center;
width:100%;
}

</style>
</head>


<head>
<div id="form-wrap">

<form>
<fieldset>
<h4 align="left">&nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp;<font size="5" color="bfb1b1"> About Us</font></h4>



</head>
<body>
	<img src="image/developer team.png" width="500" align="center">
	</fieldset>
	<p>Electronic Palace is a leading destination for online shopping in Singapore,
 offering some of the best prices and a completely hassle-free experience with 
 options of paying through Cash on Delivery, Debit Card, Credit Card and 
 Net Banking processed through secure and trusted gateways.
	</p>
	
	<p>Now shop for your
 favourite mobile phones, laptops, cameras, televisions, MP3 players and products
 from a host of other categories available. Some of the top selling electronic brands 
 on the website are Samsung, HTC, Nokia, Dell, HP, Sony, Canon, Nikon, LG, Toshiba, Philips.

	
	</p>
	
	<p>A complete set of details will be provided for each product so that customer can get the detail 
 of product and buy accordingly Browse through our cool lifestyle accessories featured on our site 
 with expert descriptions to help you arrive at the right buying decision
 </p>
 <p>Electronic Palace also offers
 free home delivery for many of our products. Get the best prices and the best online shopping experience
 every time, guaranteed at Electronic Palace.
 <p>
 It also allows you to sell the electronic products 
online. This online shopping will give you a wonderful experience to shop online. </p>


</form>
	
	
	
</body>

	&nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp
  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp  &nbsp;<a href="index.php">Return To Home</a>



</html>

<html>
<head>

<meta http-equiv="Content-Type" content="text/html;
charset=utf-8">

<title>faq </title>
<style type="text/css">

html{

background-color:#ffffff;

}

#form-wrap{

width:600px;
border: 3px solid #ccc;
background-color:#ffffff;
margin: 50px auto;
padding: 30 px 0;

}

form{
width: 700px;
height:auto;

}
input{
width:480px;
height: 40px;
margin:0 0 10px 20px;
}

select{
width:480px;
height: 40px;
margin:0 0 10px 20px;
}

textarea{
width:250px;
margin:0 0 0 20px;
}
label{
display:block;
margin:5px 0 5px 20px;
font:18px, sans-serif;
color:#888;

}
p{
margin:10px 0 0 20px;
font:14px sans-serif;
color: black;
width: 560px;
text-align:left;
}


fieldset{
border:none;
background-color :#f6f6f6f6;
padding : 0 0 20px 0;
}

.labelone{
margin-top:10px;

}

.btn{
width:125px;
background-color: #d6cfcf;
border: 1px solid #2b0606;
margin:20px 0 0 20px;
}

form h4{
margin:40px 0 0 20px;
font:24px sans-serif;
color: #4c4747;
font-weight:bold;

}
.borderit p{
border: 1px solid #ccc;
}
.borderit:hover p{
border: 2px solid Black;
}
.borderit:hover{
color: black; 
}


</style>
</head>


<head>
<div id="form-wrap">

<form>
<fieldset>
<h4 align="left">&nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp  &nbsp  &nbsp; Frequently Asked Questions</h4>



</head>
<body>
	<img src="image/faqimage.png" width="590" height="200" align="center">
	</fieldset>
	
	<div class="borderit">
	
	<p><strong>Q: Do your products come along with Guarantee/Warranty? </strong><br> A: Yes, normally all the products come under Guarantee/Warranty. The Guarantee/Warranty period is mention in the details of the products.</p>
	
	</div>
	<div class="borderit">
	<p><strong>Q: Whom should I contact if I want to cancel my product? </strong>
	<br> A: You can send us an email within 48hrs or call us on the contact details provided on our website. </p>
	
	</div>
	<div class="borderit">
	<p><strong>Q: If I want to return the product what's the procedure for that? </strong>
	<br> A: Drop us an email, our team will get back to you shortly.In the email please mention your order numeber.</p>
	</div>
	<div class="borderit">
	<p><strong>Q: In how many days I can get back my moeny once the product is returned? </strong>
	<br> A: It will take 3 working days for us to send your moneny back.</p>
	</div>
	<div class="borderit">
	<p><strong>Q: whom should I contact if I didn't receive my product on the date/time mentioned? </strong>
	<br> A: You can either drop us an email or contact us on the helpline number provided in our website.</p>
	</div>
	<div class="borderit">
	<p><strong>Q: Does the membership expire? or its life long? </strong>
	<br> A:No, The membership doesn't expire.Its life long.</p>
	</div>
	<div class="borderit">
	<p><strong>Q:I am interested in a product that is sold out. How can I buy it?  </strong>
	<br> A:Don't get dis hearted. If the product you want is not available then you can drop us an email along with your username. Once the product is available then we will notify via Email. </p>
	</div>
	<div class="borderit">
	<p><strong>Q: I am buying the product for the first time and I dont knoe how to buy the product? Can you please help me out? </strong>
	<br> A: Dont worry! Following are the steps which will guide you to purchase product from electronic palace.
	
	<br><Strong> 1. </strong> Create an Account 
	<br> <Strong> 2. </strong> Look out for the product which you want to buy. For that you can take help of <strong>Quick  &nbsp &nbsp &nbsp  &nbsp;Search.</strong>
	<br><Strong> 3. </strong> Click on the <strong> View Button </strong> to look out for ore information.
	<br><Strong> 4. </strong> Once you have selected the product the click on <strong> Add to cart </strong> Button
<br> <Strong> 5. </strong> Then go to the cart and click on the <strong> Continue </Strong> button to checkout
<br><Strong> 6. </strong> After that choose your mode of payment and input the required details and then they will provide you with a number.
<br> If you have queries after you have orderd the product you can email us using the number provided you while ordering.
<br> If you have any more queries regarding how to buy product online ,
 Please do not hesitate to log on out wesite and contact us. </p>
	</div>
	&nbsp &nbsp  &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
		&nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp  &nbsp &nbsp &nbsp
		&nbsp &nbsp &nbsp &nbsp &nbsp;<a href="index.php">Return To Home</a>
</div>
</body>




</html>
